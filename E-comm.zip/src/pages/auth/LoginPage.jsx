import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Lock, Mail, Sparkles, ShieldCheck, UserCheck, ArrowRight, Info } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login, demoLoginCustomer, demoLoginAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const redirectPath = location.state?.from || '/';

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please provide email and password.');
      return;
    }
    const res = await login(email, password);
    if (res.success) {
      navigate(redirectPath);
    } else {
      setError(res.error || 'Failed to login');
    }
  };

  const handleQuickCustomer = async () => {
    await demoLoginCustomer();
    navigate(redirectPath);
  };

  const handleQuickAdmin = async () => {
    await demoLoginAdmin();
    navigate('/admin');
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-8 col-lg-5">
          <div className="bg-white rounded-5 p-4 p-md-5 border shadow-sm">
            
            {/* Header */}
            <div className="text-center mb-4">
              <div className="tw-logo mx-auto mb-2">
                <div className="tw-logo-icon">
                  <Sparkles size={20} />
                </div>
                <span><span className="toy">Toy</span><span className="world">World</span></span>
              </div>
              <h2 className="fw-bolder h4 mb-1">Welcome Back! 👋</h2>
              <p className="text-muted small">Sign in to track orders and save your wishlist</p>
            </div>

            {/* Demo Notice */}
            <div className="alert alert-info py-2 px-3 small d-flex align-items-start gap-2 mb-4 rounded-3 border-0" style={{ background: '#e0f2fe' }}>
              <Info size={18} className="text-primary flex-shrink-0 mt-1" />
              <div>
                <strong>Frontend Demo Authentication:</strong> No real passwords required. You can use the instant 1-click buttons below or enter any sample email!
              </div>
            </div>

            {/* Quick 1-Click Buttons */}
            <div className="d-grid gap-2 mb-4">
              <button
                type="button"
                className="btn btn-outline-primary rounded-pill py-2 d-flex align-items-center justify-content-center gap-2 fw-semibold"
                onClick={handleQuickCustomer}
              >
                <UserCheck size={18} />
                <span>Quick Login: Demo Customer</span>
              </button>
              <button
                type="button"
                className="btn rounded-pill py-2 d-flex align-items-center justify-content-center gap-2 fw-semibold text-white"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #8b5cf6)' }}
                onClick={handleQuickAdmin}
              >
                <ShieldCheck size={18} />
                <span>Quick Login: Demo Admin (Full Access)</span>
              </button>
            </div>

            <div className="d-flex align-items-center my-3 text-muted">
              <hr className="flex-grow-1" />
              <span className="px-3 small text-uppercase fw-bold" style={{ fontSize: '0.75rem' }}>or sign in manually</span>
              <hr className="flex-grow-1" />
            </div>

            {error && (
              <div className="alert alert-danger py-2 small mb-3">
                {error}
              </div>
            )}

            {/* Manual Form */}
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label small fw-bold text-muted">Email Address</label>
                <div className="input-group">
                  <span className="input-group-text bg-light border-end-0 rounded-start-pill">
                    <Mail size={16} className="text-muted" />
                  </span>
                  <input
                    type="email"
                    className="form-control rounded-end-pill border-start-0"
                    placeholder="parent@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="mb-3">
                <div className="d-flex justify-content-between align-items-center">
                  <label className="form-label small fw-bold text-muted">Password</label>
                  <Link to="/forgot-password" className="small text-primary text-decoration-none">
                    Forgot Password?
                  </Link>
                </div>
                <div className="input-group">
                  <span className="input-group-text bg-light border-end-0 rounded-start-pill">
                    <Lock size={16} className="text-muted" />
                  </span>
                  <input
                    type="password"
                    className="form-control rounded-end-pill border-start-0"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="btn btn-tw-primary w-100 py-3 rounded-pill fw-bold mb-3"
                disabled={loading}
              >
                {loading ? 'Signing in...' : 'Sign In'}
              </button>
            </form>

            <div className="text-center small text-muted">
              Don't have an account?{' '}
              <Link to="/register" className="fw-bold text-primary text-decoration-none">
                Register Free
              </Link>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
