import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Mail, Lock, Phone, Sparkles, MapPin } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const RegisterPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    street: '',
    city: '',
    pincode: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState('');
  const { register, loading } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (error) setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.password) {
      setError('Please fill in required fields.');
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    const res = await register(formData);
    if (res.success) {
      navigate('/account');
    } else {
      setError(res.error || 'Registration failed');
    }
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-9 col-lg-6">
          <div className="bg-white rounded-5 p-4 p-md-5 border shadow-sm">
            
            <div className="text-center mb-4">
              <div className="tw-logo mx-auto mb-2">
                <div className="tw-logo-icon">
                  <Sparkles size={20} />
                </div>
                <span><span className="toy">Toy</span><span className="world">World</span></span>
              </div>
              <h2 className="fw-bolder h4 mb-1">Create Parent Account 🎈</h2>
              <p className="text-muted small">Join ToyWorld for discounts, wishlists, and order tracking</p>
            </div>

            {error && (
              <div className="alert alert-danger py-2 small mb-3">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit}>
              <div className="row g-3 mb-3">
                <div className="col-12">
                  <label className="form-label small fw-bold text-muted">Full Name *</label>
                  <input
                    type="text"
                    name="name"
                    className="form-control rounded-pill"
                    placeholder="e.g. Ananya Patel"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="col-md-6">
                  <label className="form-label small fw-bold text-muted">Email Address *</label>
                  <input
                    type="email"
                    name="email"
                    className="form-control rounded-pill"
                    placeholder="ananya@example.com"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="col-md-6">
                  <label className="form-label small fw-bold text-muted">Phone Number</label>
                  <input
                    type="tel"
                    name="phone"
                    className="form-control rounded-pill"
                    placeholder="+91 98765 43210"
                    value={formData.phone}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-12">
                  <label className="form-label small fw-bold text-muted">Delivery Address (Optional)</label>
                  <input
                    type="text"
                    name="street"
                    className="form-control rounded-pill"
                    placeholder="Street Address, Apartment / Flat"
                    value={formData.street}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-md-6">
                  <label className="form-label small fw-bold text-muted">City</label>
                  <input
                    type="text"
                    name="city"
                    className="form-control rounded-pill"
                    placeholder="Bengaluru"
                    value={formData.city}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-md-6">
                  <label className="form-label small fw-bold text-muted">PIN Code</label>
                  <input
                    type="text"
                    name="pincode"
                    className="form-control rounded-pill"
                    placeholder="560001"
                    value={formData.pincode}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-md-6">
                  <label className="form-label small fw-bold text-muted">Password *</label>
                  <input
                    type="password"
                    name="password"
                    className="form-control rounded-pill"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="col-md-6">
                  <label className="form-label small fw-bold text-muted">Confirm Password *</label>
                  <input
                    type="password"
                    name="confirmPassword"
                    className="form-control rounded-pill"
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="btn btn-tw-primary w-100 py-3 rounded-pill fw-bold mb-3"
                disabled={loading}
              >
                {loading ? 'Creating Account...' : 'Register Account'}
              </button>
            </form>

            <div className="text-center small text-muted">
              Already have an account?{' '}
              <Link to="/login" className="fw-bold text-primary text-decoration-none">
                Sign In
              </Link>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
