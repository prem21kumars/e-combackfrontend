import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft, CheckCircle2, Sparkles } from 'lucide-react';

export const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
    }
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-7 col-lg-5">
          <div className="bg-white rounded-5 p-4 p-md-5 border shadow-sm text-center">
            
            <div className="tw-logo mx-auto mb-2">
              <div className="tw-logo-icon">
                <Sparkles size={20} />
              </div>
              <span><span className="toy">Toy</span><span className="world">World</span></span>
            </div>

            <h2 className="fw-bolder h4 mb-2">Reset Password</h2>
            <p className="text-muted small mb-4">
              Enter the email associated with your ToyWorld demo account to receive recovery instructions.
            </p>

            {submitted ? (
              <div className="p-4 rounded-4 bg-success-subtle text-success text-center mb-4 border border-success">
                <CheckCircle2 size={40} className="mx-auto mb-2" />
                <h6 className="fw-bold mb-1">Simulated Link Sent!</h6>
                <p className="small text-muted mb-0">
                  In this demo version, a recovery link for <strong>{email}</strong> has been simulated. You can now log back in.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="text-start mb-4">
                <div className="mb-3">
                  <label className="form-label small fw-bold text-muted">Email Address</label>
                  <div className="input-group">
                    <span className="input-group-text bg-light border-end-0 rounded-start-pill">
                      <Mail size={16} className="text-muted" />
                    </span>
                    <input
                      type="email"
                      className="form-control rounded-end-pill border-start-0"
                      placeholder="parent@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <button type="submit" className="btn btn-tw-primary w-100 py-3 rounded-pill fw-bold">
                  Send Recovery Link
                </button>
              </form>
            )}

            <div>
              <Link to="/login" className="text-primary text-decoration-none small fw-bold d-inline-flex align-items-center gap-1">
                <ArrowLeft size={16} />
                <span>Back to Sign In</span>
              </Link>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;
