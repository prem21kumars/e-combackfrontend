import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Save, Sparkles, Image as ImageIcon } from 'lucide-react';
import { productService } from '../../services/productService';
import { CATEGORIES } from '../../data/categories';

export const AdminProductFormPage = () => {
  const { id } = useParams();
  const isEditMode = Boolean(id);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    category: 'Educational Toys',
    ageGroup: '3-5',
    price: '',
    discountPercentage: '0',
    stock: '20',
    image: 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?auto=format&fit=crop&w=800&q=80',
    description: '',
    isFeatured: false,
    isNewArrival: true,
    isSpecialOffer: false,
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (isEditMode) {
      setLoading(true);
      productService.getProductById(id)
        .then((prod) => {
          setFormData({
            name: prod.name || '',
            sku: prod.sku || '',
            category: prod.category || 'Educational Toys',
            ageGroup: prod.ageGroup || '3-5',
            price: String(prod.price || ''),
            discountPercentage: String(prod.discountPercentage || 0),
            stock: String(prod.stock || 0),
            image: prod.image || '',
            description: prod.description || '',
            isFeatured: Boolean(prod.isFeatured),
            isNewArrival: Boolean(prod.isNewArrival),
            isSpecialOffer: Boolean(prod.isSpecialOffer),
          });
        })
        .catch((err) => {
          alert('Could not find product');
          navigate('/admin/products');
        })
        .finally(() => setLoading(false));
    }
  }, [id, isEditMode, navigate]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const validate = () => {
    const errs = {};
    if (!formData.name.trim()) errs.name = 'Toy name is required';
    if (!formData.price || Number(formData.price) <= 0) errs.price = 'Valid price is required';
    if (!formData.stock || Number(formData.stock) < 0) errs.stock = 'Valid stock is required';
    if (!formData.image.trim()) errs.image = 'Image URL is required';
    if (!formData.description.trim()) errs.description = 'Description is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      if (isEditMode) {
        await productService.updateProduct(id, formData);
      } else {
        await productService.createProduct(formData);
      }
      navigate('/admin/products');
    } catch (err) {
      alert('Error saving product');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="d-flex flex-column gap-4">
      {/* Header */}
      <div className="d-flex align-items-center justify-content-between bg-white p-4 rounded-4 border shadow-sm">
        <div className="d-flex align-items-center gap-3">
          <Link to="/admin/products" className="btn btn-light rounded-circle p-2">
            <ArrowLeft size={18} />
          </Link>
          <div>
            <h1 className="h4 fw-bolder mb-0">
              {isEditMode ? `Edit Toy: ${formData.name}` : 'Add New Toy to Catalog'}
            </h1>
            <p className="text-muted small mb-0">Manage pricing, specifications, and demo inventory levels.</p>
          </div>
        </div>
      </div>

      {/* Form Card */}
      <div className="bg-white rounded-4 border shadow-sm p-4 p-md-5">
        <form onSubmit={handleSubmit}>
          <div className="row g-4">
            
            {/* Left Column: Core Fields */}
            <div className="col-lg-8">
              <div className="row g-3">
                <div className="col-12">
                  <label className="form-label small fw-bold text-muted">Toy Name *</label>
                  <input
                    type="text"
                    name="name"
                    className={`form-control rounded-pill ${errors.name ? 'is-invalid' : ''}`}
                    placeholder="e.g. Galaxy Explorers Spaceship Brick Set"
                    value={formData.name}
                    onChange={handleChange}
                  />
                  {errors.name && <div className="invalid-feedback small">{errors.name}</div>}
                </div>

                <div className="col-md-6">
                  <label className="form-label small fw-bold text-muted">Category *</label>
                  <select
                    name="category"
                    className="form-select rounded-pill"
                    value={formData.category}
                    onChange={handleChange}
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div className="col-md-6">
                  <label className="form-label small fw-bold text-muted">Age Group *</label>
                  <select
                    name="ageGroup"
                    className="form-select rounded-pill"
                    value={formData.ageGroup}
                    onChange={handleChange}
                  >
                    <option value="0-2">0-2 Years (Infants & Toddlers)</option>
                    <option value="3-5">3-5 Years (Preschool)</option>
                    <option value="6-8">6-8 Years (Early Grade)</option>
                    <option value="9+">9+ Years (Big Kids)</option>
                  </select>
                </div>

                <div className="col-md-4">
                  <label className="form-label small fw-bold text-muted">Original Price (₹) *</label>
                  <input
                    type="number"
                    name="price"
                    className={`form-control rounded-pill ${errors.price ? 'is-invalid' : ''}`}
                    placeholder="1499"
                    value={formData.price}
                    onChange={handleChange}
                  />
                  {errors.price && <div className="invalid-feedback small">{errors.price}</div>}
                </div>

                <div className="col-md-4">
                  <label className="form-label small fw-bold text-muted">Discount % (0-90)</label>
                  <input
                    type="number"
                    name="discountPercentage"
                    className="form-control rounded-pill"
                    placeholder="15"
                    value={formData.discountPercentage}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-md-4">
                  <label className="form-label small fw-bold text-muted">Inventory Stock Units *</label>
                  <input
                    type="number"
                    name="stock"
                    className={`form-control rounded-pill ${errors.stock ? 'is-invalid' : ''}`}
                    placeholder="25"
                    value={formData.stock}
                    onChange={handleChange}
                  />
                  {errors.stock && <div className="invalid-feedback small">{errors.stock}</div>}
                </div>

                <div className="col-12">
                  <label className="form-label small fw-bold text-muted">Toy Description *</label>
                  <textarea
                    rows="4"
                    name="description"
                    className={`form-control rounded-4 ${errors.description ? 'is-invalid' : ''}`}
                    placeholder="Detailed explanation of features, child development benefits, and materials..."
                    value={formData.description}
                    onChange={handleChange}
                  ></textarea>
                  {errors.description && <div className="invalid-feedback small">{errors.description}</div>}
                </div>
              </div>
            </div>

            {/* Right Column: Image Preview & Badges */}
            <div className="col-lg-4">
              <div className="p-3 rounded-4 bg-light border mb-4">
                <label className="form-label small fw-bold text-muted d-flex align-items-center gap-1">
                  <ImageIcon size={16} />
                  <span>Image Preview</span>
                </label>
                <div className="rounded-3 overflow-hidden bg-white border text-center mb-3" style={{ height: '200px' }}>
                  <img
                    src={formData.image}
                    alt="Preview"
                    className="w-100 h-100 object-fit-cover"
                    onError={(e) => {
                      e.target.src = 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?auto=format&fit=crop&w=600&q=80';
                    }}
                  />
                </div>
                <input
                  type="url"
                  name="image"
                  className="form-control form-control-sm rounded-pill"
                  placeholder="https://images.unsplash.com/..."
                  value={formData.image}
                  onChange={handleChange}
                />
                <small className="text-muted d-block mt-1" style={{ fontSize: '0.72rem' }}>
                  Enter a direct image URL or Unsplash photo link.
                </small>
              </div>

              {/* Promotional Flags */}
              <div className="p-3 rounded-4 bg-light border">
                <label className="form-label small fw-bold text-muted mb-2">Display Badges</label>
                <div className="form-check mb-2">
                  <input
                    type="checkbox"
                    id="isFeatured"
                    name="isFeatured"
                    className="form-check-input"
                    checked={formData.isFeatured}
                    onChange={handleChange}
                  />
                  <label className="form-check-label small" htmlFor="isFeatured">
                    Featured on Homepage
                  </label>
                </div>
                <div className="form-check mb-2">
                  <input
                    type="checkbox"
                    id="isNewArrival"
                    name="isNewArrival"
                    className="form-check-input"
                    checked={formData.isNewArrival}
                    onChange={handleChange}
                  />
                  <label className="form-check-label small" htmlFor="isNewArrival">
                    Mark as New Arrival
                  </label>
                </div>
                <div className="form-check">
                  <input
                    type="checkbox"
                    id="isSpecialOffer"
                    name="isSpecialOffer"
                    className="form-check-input"
                    checked={formData.isSpecialOffer}
                    onChange={handleChange}
                  />
                  <label className="form-check-label small" htmlFor="isSpecialOffer">
                    Highlight as Special Offer
                  </label>
                </div>
              </div>
            </div>

          </div>

          <div className="d-flex justify-content-end gap-3 pt-4 border-top mt-4">
            <Link to="/admin/products" className="btn btn-light rounded-pill px-4">
              Cancel
            </Link>
            <button
              type="submit"
              className="btn btn-tw-primary rounded-pill px-5 d-flex align-items-center gap-2"
              disabled={loading}
            >
              <Save size={18} />
              <span>{loading ? 'Saving...' : isEditMode ? 'Update Toy' : 'Create Toy'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminProductFormPage;
