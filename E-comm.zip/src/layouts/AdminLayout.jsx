import React, { useState } from 'react';
import { Outlet, NavLink, Link, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Package, 
  PlusCircle, 
  FolderTree, 
  ShoppingBag, 
  Boxes, 
  BarChart3, 
  Store, 
  Menu, 
  X, 
  ShieldCheck, 
  LogOut,
  Sparkles,
  RotateCcw
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { productService } from '../services/productService';
import Toast from '../components/common/Toast';

export const AdminLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, logout, demoLoginAdmin } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const handleResetData = async () => {
    if (window.confirm('Reset all demo products & orders back to initial catalog?')) {
      await productService.resetToDefaults();
      window.location.reload();
    }
  };

  return (
    <div className="d-flex min-vh-100 bg-light">
      {/* Mobile Sidebar Backdrop */}
      {sidebarOpen && (
        <div 
          className="admin-backdrop d-md-none" 
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Admin Sidebar */}
      <aside 
        className={`admin-sidebar bg-white border-end d-flex flex-column justify-content-between p-3 ${
          sidebarOpen ? 'show' : ''
        }`}
        style={{ width: '270px', minWidth: '270px' }}
      >
        <div>
          {/* Logo & Close */}
          <div className="d-flex align-items-center justify-content-between pb-3 border-bottom mb-3">
            <Link to="/admin" className="tw-logo text-decoration-none">
              <div className="tw-logo-icon">
                <Sparkles size={20} />
              </div>
              <span><span className="toy">Toy</span><span className="world">Admin</span></span>
            </Link>
            <button 
              type="button" 
              className="btn btn-light d-md-none p-1 rounded-circle"
              onClick={() => setSidebarOpen(false)}
            >
              <X size={20} />
            </button>
          </div>

          {/* Admin Navigation Menu */}
          <div className="text-muted small fw-bold px-2 mb-2 text-uppercase" style={{ fontSize: '0.75rem' }}>
            Operations & Catalog
          </div>
          <nav className="nav flex-column gap-1">
            <NavLink
              to="/admin"
              end
              className={({ isActive }) =>
                `nav-link d-flex align-items-center gap-3 px-3 py-2 rounded-3 fw-semibold ${
                  isActive ? 'bg-primary text-white shadow-sm' : 'text-secondary hover-bg-light'
                }`
              }
              onClick={() => setSidebarOpen(false)}
            >
              <LayoutDashboard size={18} />
              <span>Overview</span>
            </NavLink>

            <NavLink
              to="/admin/products"
              className={({ isActive }) =>
                `nav-link d-flex align-items-center gap-3 px-3 py-2 rounded-3 fw-semibold ${
                  isActive ? 'bg-primary text-white shadow-sm' : 'text-secondary hover-bg-light'
                }`
              }
              onClick={() => setSidebarOpen(false)}
            >
              <Package size={18} />
              <span>Products</span>
            </NavLink>

            <NavLink
              to="/admin/products/new"
              className={({ isActive }) =>
                `nav-link d-flex align-items-center gap-3 px-3 py-2 rounded-3 fw-semibold ${
                  isActive ? 'bg-primary text-white shadow-sm' : 'text-secondary hover-bg-light'
                }`
              }
              onClick={() => setSidebarOpen(false)}
            >
              <PlusCircle size={18} />
              <span>Add Product</span>
            </NavLink>

            <NavLink
              to="/admin/categories"
              className={({ isActive }) =>
                `nav-link d-flex align-items-center gap-3 px-3 py-2 rounded-3 fw-semibold ${
                  isActive ? 'bg-primary text-white shadow-sm' : 'text-secondary hover-bg-light'
                }`
              }
              onClick={() => setSidebarOpen(false)}
            >
              <FolderTree size={18} />
              <span>Categories</span>
            </NavLink>

            <NavLink
              to="/admin/orders"
              className={({ isActive }) =>
                `nav-link d-flex align-items-center gap-3 px-3 py-2 rounded-3 fw-semibold ${
                  isActive ? 'bg-primary text-white shadow-sm' : 'text-secondary hover-bg-light'
                }`
              }
              onClick={() => setSidebarOpen(false)}
            >
              <ShoppingBag size={18} />
              <span>Orders</span>
            </NavLink>

            <NavLink
              to="/admin/inventory"
              className={({ isActive }) =>
                `nav-link d-flex align-items-center gap-3 px-3 py-2 rounded-3 fw-semibold ${
                  isActive ? 'bg-primary text-white shadow-sm' : 'text-secondary hover-bg-light'
                }`
              }
              onClick={() => setSidebarOpen(false)}
            >
              <Boxes size={18} />
              <span>Inventory</span>
            </NavLink>

            <NavLink
              to="/admin/reports"
              className={({ isActive }) =>
                `nav-link d-flex align-items-center gap-3 px-3 py-2 rounded-3 fw-semibold ${
                  isActive ? 'bg-primary text-white shadow-sm' : 'text-secondary hover-bg-light'
                }`
              }
              onClick={() => setSidebarOpen(false)}
            >
              <BarChart3 size={18} />
              <span>Reports</span>
            </NavLink>
          </nav>
        </div>

        {/* Sidebar Footer */}
        <div className="pt-3 border-top">
          <div className="d-grid gap-2">
            <Link 
              to="/" 
              className="btn btn-outline-primary btn-sm rounded-pill d-flex align-items-center justify-content-center gap-2"
            >
              <Store size={16} />
              <span>View Customer Store</span>
            </Link>

            <button
              type="button"
              className="btn btn-light btn-sm rounded-pill text-muted d-flex align-items-center justify-content-center gap-2"
              onClick={handleResetData}
              title="Reset all demo data back to factory dataset"
            >
              <RotateCcw size={14} />
              <span>Reset Demo Data</span>
            </button>

            <button
              type="button"
              className="btn btn-link text-danger btn-sm text-decoration-none d-flex align-items-center justify-content-center gap-1"
              onClick={handleLogout}
            >
              <LogOut size={14} />
              <span>Exit Admin</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Admin Area */}
      <div className="flex-grow-1 d-flex flex-column min-vh-100 overflow-hidden">
        {/* Top Navbar */}
        <header className="bg-white border-bottom px-4 py-3 d-flex align-items-center justify-content-between">
          <div className="d-flex align-items-center gap-3">
            <button
              type="button"
              className="btn btn-light d-md-none p-2 rounded-3"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu size={20} />
            </button>
            <div>
              <span className="badge bg-purple-subtle text-purple fw-bold px-2 py-1 rounded-pill" style={{ background: '#ede9fe', color: '#7c3aed' }}>
                <ShieldCheck size={14} className="me-1" />
                Frontend Demo Admin Portal
              </span>
            </div>
          </div>

          <div className="d-flex align-items-center gap-3">
            <div className="text-end d-none d-sm-block">
              <div className="fw-bold small">{user?.name || 'Administrator'}</div>
              <div className="text-muted" style={{ fontSize: '0.75rem' }}>Full Access Demo</div>
            </div>
            <div 
              className="rounded-circle d-flex align-items-center justify-content-center fw-bold text-white"
              style={{ width: '38px', height: '38px', background: 'linear-gradient(135deg, #7c3aed, #0284c7)' }}
            >
              A
            </div>
          </div>
        </header>

        {/* Admin Content Outlet */}
        <main className="p-3 p-md-4 flex-grow-1 overflow-auto">
          <Outlet />
        </main>
      </div>

      <Toast />
    </div>
  );
};

export default AdminLayout;
