import { getStorageItem, setStorageItem, removeStorageItem } from '../utils/storage';

const AUTH_STORAGE_KEY = 'toyworld_auth';

// Initial demo users
export const DEMO_USERS = {
  customer: {
    id: 'usr_demo_01',
    name: 'Priya Sharma',
    email: 'priya@example.com',
    role: 'customer',
    phone: '+91 98765 43210',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    addresses: [
      {
        id: 'addr_1',
        title: 'Home',
        street: 'Flat 402, Lotus Residency, MG Road',
        city: 'Bengaluru',
        state: 'Karnataka',
        pincode: '560001',
        isDefault: true,
      },
    ],
  },
  admin: {
    id: 'usr_admin_01',
    name: 'ToyWorld Admin',
    email: 'admin@toyworld.com',
    role: 'admin',
    phone: '+91 99999 88888',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    addresses: [],
  },
};

export const authService = {
  /**
   * Get currently logged-in demo user session
   */
  getCurrentUser() {
    return getStorageItem(AUTH_STORAGE_KEY, null);
  },

  /**
   * Simulated login
   * Future Spring Boot endpoint: POST /api/auth/login
   */
  async login(email, password, role = 'customer') {
    // Check if it's admin or customer
    let user;
    if (email.toLowerCase().includes('admin') || role === 'admin') {
      user = { ...DEMO_USERS.admin };
    } else {
      user = {
        ...DEMO_USERS.customer,
        email: email || DEMO_USERS.customer.email,
        name: email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()) || 'Toy Explorer',
      };
    }

    const authPayload = {
      user,
      token: `demo_jwt_token_${Date.now()}`,
      loginTime: new Date().toISOString(),
    };

    setStorageItem(AUTH_STORAGE_KEY, authPayload);
    return Promise.resolve(user);
  },

  /**
   * Simulated registration
   * Future Spring Boot endpoint: POST /api/auth/register
   */
  async register(userData) {
    const newUser = {
      id: `usr_${Date.now()}`,
      name: userData.name || 'New ToyWorld Member',
      email: userData.email,
      role: 'customer',
      phone: userData.phone || '',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      addresses: userData.street
        ? [
            {
              id: 'addr_new',
              title: 'Home',
              street: userData.street,
              city: userData.city || '',
              state: userData.state || '',
              pincode: userData.pincode || '',
              isDefault: true,
            },
          ]
        : [],
    };

    const authPayload = {
      user: newUser,
      token: `demo_jwt_token_${Date.now()}`,
      loginTime: new Date().toISOString(),
    };

    setStorageItem(AUTH_STORAGE_KEY, authPayload);
    return Promise.resolve(newUser);
  },

  /**
   * Update customer profile
   * Future Spring Boot endpoint: PUT /api/users/profile
   */
  async updateProfile(updatedData) {
    const current = this.getCurrentUser();
    if (!current) {
      return Promise.reject(new Error('No active demo session'));
    }

    const updatedUser = {
      ...current.user,
      ...updatedData,
    };

    const updatedPayload = {
      ...current,
      user: updatedUser,
    };

    setStorageItem(AUTH_STORAGE_KEY, updatedPayload);
    return Promise.resolve(updatedUser);
  },

  /**
   * Logout
   */
  async logout() {
    removeStorageItem(AUTH_STORAGE_KEY);
    return Promise.resolve(true);
  },
};
