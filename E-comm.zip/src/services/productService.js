import { INITIAL_PRODUCTS } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { getStorageItem, setStorageItem } from '../utils/storage';

const PRODUCTS_STORAGE_KEY = 'toyworld_products';
const CATEGORIES_STORAGE_KEY = 'toyworld_categories';

/**
 * Initialize storage with default products and categories if empty
 */
const initProductsStorage = () => {
  const existing = getStorageItem(PRODUCTS_STORAGE_KEY);
  if (!existing || !Array.isArray(existing) || existing.length === 0) {
    setStorageItem(PRODUCTS_STORAGE_KEY, INITIAL_PRODUCTS);
    return INITIAL_PRODUCTS;
  }
  return existing;
};

const initCategoriesStorage = () => {
  const existing = getStorageItem(CATEGORIES_STORAGE_KEY);
  if (!existing || !Array.isArray(existing) || existing.length === 0) {
    setStorageItem(CATEGORIES_STORAGE_KEY, CATEGORIES);
    return CATEGORIES;
  }
  return existing;
};

export const productService = {
  /**
   * Fetch all products with optional filters
   * Future Spring Boot endpoint: GET /api/products?category=...&age=...&search=...
   */
  async getProducts(params = {}) {
    const products = initProductsStorage();
    let filtered = [...products];

    // Filter by active status (if products have isActive flag, default true)
    filtered = filtered.filter((p) => p.isActive !== false);

    // Filter by Category
    if (params.category && params.category !== 'all') {
      const catLower = params.category.toLowerCase().replace(/-/g, ' ');
      filtered = filtered.filter((p) => 
        p.category.toLowerCase() === catLower ||
        p.category.toLowerCase().replace(/\s+/g, '-') === params.category.toLowerCase()
      );
    }

    // Filter by Age Group
    if (params.ageGroup && params.ageGroup !== 'all') {
      filtered = filtered.filter((p) => p.ageGroup === params.ageGroup);
    }

    // Filter by Price Range
    if (params.minPrice !== undefined && params.minPrice !== '') {
      filtered = filtered.filter((p) => {
        const discounted = p.price - (p.price * (p.discountPercentage || 0)) / 100;
        return discounted >= Number(params.minPrice);
      });
    }
    if (params.maxPrice !== undefined && params.maxPrice !== '') {
      filtered = filtered.filter((p) => {
        const discounted = p.price - (p.price * (p.discountPercentage || 0)) / 100;
        return discounted <= Number(params.maxPrice);
      });
    }

    // Search query
    if (params.search && params.search.trim()) {
      const q = params.search.toLowerCase().trim();
      filtered = filtered.filter((p) =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q)
      );
    }

    // Sorting
    if (params.sortBy) {
      switch (params.sortBy) {
        case 'price-asc':
          filtered.sort((a, b) => {
            const priceA = a.price - (a.price * (a.discountPercentage || 0)) / 100;
            const priceB = b.price - (b.price * (b.discountPercentage || 0)) / 100;
            return priceA - priceB;
          });
          break;
        case 'price-desc':
          filtered.sort((a, b) => {
            const priceA = a.price - (a.price * (a.discountPercentage || 0)) / 100;
            const priceB = b.price - (b.price * (b.discountPercentage || 0)) / 100;
            return priceB - priceA;
          });
          break;
        case 'name-asc':
          filtered.sort((a, b) => a.name.localeCompare(b.name));
          break;
        case 'rating':
          filtered.sort((a, b) => b.rating - a.rating);
          break;
        case 'popularity':
        default:
          filtered.sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
          break;
      }
    }

    return Promise.resolve(filtered);
  },

  /**
   * Fetch single product by ID
   * Future Spring Boot endpoint: GET /api/products/{id}
   */
  async getProductById(id) {
    const products = initProductsStorage();
    const found = products.find((p) => String(p.id) === String(id));
    if (!found) {
      return Promise.reject(new Error(`Product with ID ${id} not found`));
    }
    return Promise.resolve(found);
  },

  /**
   * Fetch all categories
   * Future Spring Boot endpoint: GET /api/categories
   */
  async getCategories() {
    return Promise.resolve(initCategoriesStorage());
  },

  /**
   * Admin: Add new product
   * Future Spring Boot endpoint: POST /api/admin/products
   */
  async createProduct(productData) {
    const products = initProductsStorage();
    const newId = products.length > 0 ? Math.max(...products.map((p) => p.id)) + 1 : 1;
    const newProduct = {
      id: newId,
      sku: productData.sku || `TW-PRD-${String(newId).padStart(4, '0')}`,
      rating: 5.0,
      reviewsCount: 1,
      popularity: 50,
      isFeatured: false,
      isNewArrival: true,
      isActive: true,
      ...productData,
      price: Number(productData.price),
      discountPercentage: Number(productData.discountPercentage || 0),
      stock: Number(productData.stock || 0),
    };
    const updatedList = [newProduct, ...products];
    setStorageItem(PRODUCTS_STORAGE_KEY, updatedList);
    return Promise.resolve(newProduct);
  },

  /**
   * Admin: Update product
   * Future Spring Boot endpoint: PUT /api/admin/products/{id}
   */
  async updateProduct(id, productData) {
    const products = initProductsStorage();
    const index = products.findIndex((p) => String(p.id) === String(id));
    if (index === -1) {
      return Promise.reject(new Error(`Product with ID ${id} not found`));
    }
    const updatedProduct = {
      ...products[index],
      ...productData,
      price: Number(productData.price),
      discountPercentage: Number(productData.discountPercentage || 0),
      stock: Number(productData.stock || 0),
    };
    products[index] = updatedProduct;
    setStorageItem(PRODUCTS_STORAGE_KEY, products);
    return Promise.resolve(updatedProduct);
  },

  /**
   * Admin: Delete/Deactivate product
   * Future Spring Boot endpoint: DELETE /api/admin/products/{id}
   */
  async deleteProduct(id) {
    const products = initProductsStorage();
    const filtered = products.filter((p) => String(p.id) !== String(id));
    setStorageItem(PRODUCTS_STORAGE_KEY, filtered);
    return Promise.resolve(true);
  },

  /**
   * Reset products back to demo defaults
   */
  async resetToDefaults() {
    setStorageItem(PRODUCTS_STORAGE_KEY, INITIAL_PRODUCTS);
    setStorageItem(CATEGORIES_STORAGE_KEY, CATEGORIES);
    return Promise.resolve(INITIAL_PRODUCTS);
  },
};
