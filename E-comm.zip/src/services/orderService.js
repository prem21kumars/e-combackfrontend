import { INITIAL_ORDERS } from '../data/demoOrders';
import { getStorageItem, setStorageItem } from '../utils/storage';

const ORDERS_STORAGE_KEY = 'toyworld_orders';

const initOrdersStorage = () => {
  const existing = getStorageItem(ORDERS_STORAGE_KEY);
  if (!existing || !Array.isArray(existing) || existing.length === 0) {
    setStorageItem(ORDERS_STORAGE_KEY, INITIAL_ORDERS);
    return INITIAL_ORDERS;
  }
  return existing;
};

export const orderService = {
  /**
   * Get all orders (for admin or filtering by customer email)
   * Future Spring Boot endpoint: GET /api/orders
   */
  async getOrders(customerEmail = null) {
    const orders = initOrdersStorage();
    if (customerEmail) {
      return Promise.resolve(
        orders.filter((o) => o.customer?.email?.toLowerCase() === customerEmail.toLowerCase())
      );
    }
    return Promise.resolve(orders);
  },

  /**
   * Get order by ID
   * Future Spring Boot endpoint: GET /api/orders/{id}
   */
  async getOrderById(orderId) {
    const orders = initOrdersStorage();
    const found = orders.find((o) => String(o.id) === String(orderId));
    if (!found) {
      return Promise.reject(new Error(`Order ${orderId} not found`));
    }
    return Promise.resolve(found);
  },

  /**
   * Create a new simulated demo order
   * Future Spring Boot endpoint: POST /api/orders
   */
  async createOrder(orderPayload) {
    const orders = initOrdersStorage();
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const newOrderId = `TW-ORD-${randomNum}`;
    const nowIso = new Date().toISOString();

    const newOrder = {
      id: newOrderId,
      date: nowIso,
      customer: orderPayload.customer,
      items: orderPayload.items,
      subtotal: orderPayload.subtotal,
      shipping: orderPayload.shipping || 0,
      discount: orderPayload.discount || 0,
      total: orderPayload.total,
      paymentMethod: orderPayload.paymentMethod || 'Razorpay Demo (UPI)',
      paymentStatus: orderPayload.paymentMethod?.includes('Cash') ? 'Pending' : 'Paid (Demo Simulation)',
      orderStatus: 'Ordered',
      trackingNumber: `TRK-IND-${Math.floor(100000 + Math.random() * 900000)}`,
      statusTimeline: [
        {
          status: 'Ordered',
          timestamp: nowIso,
          notes: 'Demo order successfully simulated and confirmed.',
        },
      ],
    };

    const updated = [newOrder, ...orders];
    setStorageItem(ORDERS_STORAGE_KEY, updated);
    return Promise.resolve(newOrder);
  },

  /**
   * Update order status (Admin operation)
   * Future Spring Boot endpoint: PATCH /api/admin/orders/{id}/status
   */
  async updateOrderStatus(orderId, newStatus, notes = '') {
    const orders = initOrdersStorage();
    const index = orders.findIndex((o) => String(o.id) === String(orderId));
    if (index === -1) {
      return Promise.reject(new Error(`Order ${orderId} not found`));
    }

    const order = orders[index];
    const updatedTimeline = [
      ...order.statusTimeline,
      {
        status: newStatus,
        timestamp: new Date().toISOString(),
        notes: notes || `Order status updated to ${newStatus}.`,
      },
    ];

    const updatedOrder = {
      ...order,
      orderStatus: newStatus,
      statusTimeline: updatedTimeline,
    };

    orders[index] = updatedOrder;
    setStorageItem(ORDERS_STORAGE_KEY, orders);
    return Promise.resolve(updatedOrder);
  },

  /**
   * Customer demo cancellation request
   * Future Spring Boot endpoint: POST /api/orders/{id}/cancel
   */
  async requestCancellation(orderId, reason = 'Customer request') {
    return this.updateOrderStatus(orderId, 'Cancelled', `Cancellation requested: ${reason}`);
  },
};
