import axios from 'axios';

/**
 * ToyWorld API Client
 * Configured for future Spring Boot REST API integration.
 * In this frontend-only phase, service modules intercept or fallback to
 * LocalStorage demo data, but this client structure is 100% ready for
 * when the Spring Boot backend is connected.
 */

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/api';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

// Interceptor for attaching demo or future JWT bearer tokens
apiClient.interceptors.request.use(
  (config) => {
    try {
      const authData = localStorage.getItem('toyworld_auth');
      if (authData) {
        const { token } = JSON.parse(authData);
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
      }
    } catch (e) {
      // Ignore token read errors in demo mode
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // Graceful handling for future 401 / 403 / 500 Spring Boot responses
    return Promise.reject(error);
  }
);

export default apiClient;
