import React, { createContext, useContext, useState, useEffect } from 'react';
import { getStorageItem, setStorageItem } from '../utils/storage';

const CartContext = createContext();
const CART_STORAGE_KEY = 'toyworld_cart';
const PROMO_STORAGE_KEY = 'toyworld_promo';

const VALID_PROMOS = {
  TOYJOY10: { type: 'percent', value: 10, label: '10% OFF Special Joy Discount' },
  SUPERKID: { type: 'flat', value: 300, minOrder: 1500, label: '₹300 OFF SuperKid Bonus' },
  FIRSTTOY: { type: 'percent', value: 15, label: '15% First Order Welcome' },
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(() => getStorageItem(CART_STORAGE_KEY, []));
  const [promoCode, setPromoCode] = useState(() => getStorageItem(PROMO_STORAGE_KEY, null));
  const [notification, setNotification] = useState(null);

  useEffect(() => {
    setStorageItem(CART_STORAGE_KEY, cartItems);
  }, [cartItems]);

  useEffect(() => {
    if (promoCode) {
      setStorageItem(PROMO_STORAGE_KEY, promoCode);
    } else {
      localStorage.removeItem(PROMO_STORAGE_KEY);
    }
  }, [promoCode]);

  const showToast = (message, type = 'success') => {
    setNotification({ message, type, id: Date.now() });
    setTimeout(() => {
      setNotification(null);
    }, 3000);
  };

  /**
   * Add product to cart with chosen quantity
   */
  const addToCart = (product, quantity = 1) => {
    const qty = Math.max(1, parseInt(quantity, 10) || 1);
    setCartItems((prevItems) => {
      const existingIndex = prevItems.findIndex((item) => item.id === product.id);
      const discountedPrice = product.discountPercentage > 0
        ? Math.round(product.price - (product.price * product.discountPercentage) / 100)
        : product.price;

      if (existingIndex > -1) {
        const updated = [...prevItems];
        const newQty = updated[existingIndex].quantity + qty;
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: newQty,
        };
        showToast(`Updated "${product.name}" quantity to ${newQty}!`);
        return updated;
      } else {
        const newItem = {
          id: product.id,
          name: product.name,
          sku: product.sku,
          category: product.category,
          price: product.price,
          discountedPrice,
          discountPercentage: product.discountPercentage || 0,
          image: product.image,
          stock: product.stock,
          quantity: qty,
        };
        showToast(`Added "${product.name}" to your cart! 🛍️`);
        return [...prevItems, newItem];
      }
    });
  };

  /**
   * Update quantity of a product
   */
  const updateQuantity = (productId, newQuantity) => {
    const qty = parseInt(newQuantity, 10);
    if (qty <= 0) {
      removeFromCart(productId);
      return;
    }

    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.id === productId ? { ...item, quantity: qty } : item
      )
    );
  };

  /**
   * Remove product from cart
   */
  const removeFromCart = (productId) => {
    setCartItems((prevItems) => {
      const itemToRemove = prevItems.find((item) => item.id === productId);
      if (itemToRemove) {
        showToast(`Removed "${itemToRemove.name}" from cart.`);
      }
      return prevItems.filter((item) => item.id !== productId);
    });
  };

  /**
   * Clear all items
   */
  const clearCart = () => {
    setCartItems([]);
    setPromoCode(null);
  };

  /**
   * Apply promotional coupon code
   */
  const applyPromoCode = (code) => {
    const cleanCode = code ? code.trim().toUpperCase() : '';
    if (VALID_PROMOS[cleanCode]) {
      setPromoCode({ code: cleanCode, ...VALID_PROMOS[cleanCode] });
      showToast(`Promo "${cleanCode}" applied successfully! 🎉`);
      return { success: true, message: 'Promo applied successfully!' };
    } else {
      return { success: false, message: 'Invalid promo code. Try TOYJOY10 or SUPERKID' };
    }
  };

  const removePromoCode = () => {
    setPromoCode(null);
    showToast('Promo code removed.');
  };

  // Calculations
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.discountedPrice * item.quantity,
    0
  );

  const originalTotal = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const productSavings = originalTotal - subtotal;

  // Shipping: Free above ₹999, else ₹99
  const shipping = subtotal === 0 || subtotal >= 999 ? 0 : 99;

  // Coupon discount calculation
  let promoDiscount = 0;
  if (promoCode && subtotal > 0) {
    if (promoCode.type === 'percent') {
      promoDiscount = Math.round((subtotal * promoCode.value) / 100);
    } else if (promoCode.type === 'flat') {
      if (!promoCode.minOrder || subtotal >= promoCode.minOrder) {
        promoDiscount = promoCode.value;
      }
    }
  }

  const total = Math.max(0, subtotal - promoDiscount + shipping);

  return (
    <CartContext.Provider
      value={{
        cartItems,
        cartCount,
        subtotal,
        originalTotal,
        productSavings,
        shipping,
        promoDiscount,
        promoCode,
        total,
        notification,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        applyPromoCode,
        removePromoCode,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
